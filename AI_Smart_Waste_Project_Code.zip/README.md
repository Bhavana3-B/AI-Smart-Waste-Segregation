# AI-Driven Smart Waste Segregation and Compost Management System

Starter prototype package:
- ESP32 sensor monitoring and actuator control
- Python API/dashboard
- TensorFlow image-classifier training script

## Hardware assumed
ESP32, DS18B20 temperature sensor (GPIO 4), capacitive moisture sensor (GPIO 34), servo (GPIO 18), pump relay (GPIO 26), fan relay (GPIO 27).

## Setup
1. Install Python 3.10/3.11.
2. `cd server` and run `pip install -r requirements.txt`
3. Create `server/dataset/` folders: `food_waste`, `fruit_vegetable`, `paper`, `plastic`, `metal`, `other`, then add labelled images.
4. Train: `python train_model.py --data_dir dataset --output waste_model.keras`
5. Keep `waste_model.keras` and `class_names.json` in `server/`, then run `python app.py`.
6. Open `http://127.0.0.1:5000` on the computer. In the ESP32 sketch, change Wi-Fi credentials and `SERVER_URL` to the computer's LAN IP, e.g. `http://192.168.1.10:5000/api/sensor`.

Install Arduino libraries: OneWire, DallasTemperature, ESP32Servo, ArduinoJson.

Important: calibrate the moisture sensor. Check whether relays are active HIGH or LOW. Never power motors directly from ESP32 pins; use suitable driver circuits and separate supplies with common ground. Test mechanisms with harmless objects first. This is a prototype starter, not a certified product. The image classifier must be trained and evaluated with your own representative images before automated sorting.
