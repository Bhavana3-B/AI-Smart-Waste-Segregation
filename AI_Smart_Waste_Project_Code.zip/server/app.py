from pathlib import Path
from datetime import datetime, timezone
import json
from flask import Flask, request, jsonify, render_template_string
from PIL import Image
import numpy as np

app = Flask(__name__)
HERE = Path(__file__).resolve().parent
latest = {"temperature_c": None, "moisture_percent": None, "device": "not connected", "updated_at": None}
model, class_names = None, []

try:
    if (HERE / "waste_model.keras").exists() and (HERE / "class_names.json").exists():
        import tensorflow as tf
        model = tf.keras.models.load_model(HERE / "waste_model.keras")
        class_names = json.loads((HERE / "class_names.json").read_text(encoding="utf-8"))
except Exception as exc:
    print("Model loading failed:", exc)

@app.get("/")
def home():
    return render_template_string("""
    <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Smart Waste Dashboard</title><style>
    body{font-family:Arial;max-width:700px;margin:25px auto;padding:0 15px;background:#f4f7f4}
    .card{background:white;padding:20px;margin:12px 0;border-radius:10px}
    h1{color:#236b45}</style></head><body>
    <h1>Smart Waste & Compost Dashboard</h1><p>Prototype sensor readings; refreshes every 5 seconds.</p>
    <div class="card">Temperature: <b id="t">--</b></div>
    <div class="card">Moisture: <b id="m">--</b></div>
    <div class="card">Last update: <span id="u">Waiting for ESP32</span></div>
    <script>async function refresh(){try{let d=await(await fetch('/api/status')).json();
    t.textContent=d.temperature_c==null?'--':d.temperature_c+' °C';
    m.textContent=d.moisture_percent==null?'--':d.moisture_percent+' %';
    u.textContent=d.updated_at||'Waiting for ESP32';}catch(e){u.textContent='API unavailable';}}
    refresh();setInterval(refresh,5000);</script></body></html>
    """)

@app.get("/api/status")
def status():
    return jsonify(latest)

@app.post("/api/sensor")
def sensor():
    d = request.get_json(silent=True) or {}
    try:
        t, m = float(d["temperature_c"]), float(d["moisture_percent"])
        if not (-20 <= t <= 100 and 0 <= m <= 100): raise ValueError("out of range")
    except (KeyError, TypeError, ValueError) as e:
        return jsonify({"error": "Invalid sensor values: " + str(e)}), 400
    latest.update({"temperature_c": round(t, 2), "moisture_percent": round(m, 1),
                   "device": str(d.get("device", "esp32")),
                   "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
    return jsonify({"ok": True})

@app.post("/api/classify")
def classify():
    if model is None:
        return jsonify({"error": "No trained model. Train it and place waste_model.keras and class_names.json in server/."}), 503
    if "image" not in request.files:
        return jsonify({"error": "Upload image in a form field named 'image'."}), 400
    try:
        img = Image.open(request.files["image"].stream).convert("RGB").resize((224, 224))
        arr = np.asarray(img, dtype=np.float32)[None, ...]
        probs = model.predict(arr, verbose=0)[0]
        i = int(np.argmax(probs))
        return jsonify({"class": class_names[i], "confidence": round(float(probs[i]), 4),
                        "warning": "Prototype prediction; verify before sorting."})
    except Exception as e:
        return jsonify({"error": "Could not classify image: " + str(e)}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
