Create these folders and add labelled images:
food_waste/
fruit_vegetable/
paper/
plastic/
metal/
other/

Use varied images and lighting. Keep test images separate when evaluating model performance.
