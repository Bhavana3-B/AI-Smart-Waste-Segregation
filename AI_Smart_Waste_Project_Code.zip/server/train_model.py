import argparse, json
from pathlib import Path
import tensorflow as tf

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", required=True)
    p.add_argument("--output", default="waste_model.keras")
    p.add_argument("--epochs", type=int, default=8)
    args = p.parse_args()
    data_dir = Path(args.data_dir)
    train = tf.keras.utils.image_dataset_from_directory(
        data_dir, validation_split=0.2, subset="training", seed=123,
        image_size=(224, 224), batch_size=32)
    val = tf.keras.utils.image_dataset_from_directory(
        data_dir, validation_split=0.2, subset="validation", seed=123,
        image_size=(224, 224), batch_size=32)
    labels = train.class_names
    Path("class_names.json").write_text(json.dumps(labels, indent=2), encoding="utf-8")
    train = train.cache().shuffle(500).prefetch(tf.data.AUTOTUNE)
    val = val.cache().prefetch(tf.data.AUTOTUNE)

    base = tf.keras.applications.MobileNetV2(
        input_shape=(224, 224, 3), include_top=False, weights="imagenet")
    base.trainable = False
    inputs = tf.keras.Input(shape=(224, 224, 3))
    x = tf.keras.applications.mobilenet_v2.preprocess_input(inputs)
    x = base(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(0.2)(x)
    outputs = tf.keras.layers.Dense(len(labels), activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.fit(train, validation_data=val, epochs=args.epochs)
    model.save(args.output)
    print("Saved model:", args.output)
    print("Classes:", labels)
    print("Test separately before using predictions for automatic sorting.")

if __name__ == "__main__":
    main()
