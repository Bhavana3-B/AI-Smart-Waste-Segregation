#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL = "http://192.168.1.10:5000/api/sensor";

const int TEMP_PIN = 4;
const int MOISTURE_PIN = 34;
const int SERVO_PIN = 18;
const int PUMP_RELAY_PIN = 26;
const int FAN_RELAY_PIN = 27;

// Change these to match your relay board.
const int RELAY_ON = LOW;
const int RELAY_OFF = HIGH;

// Calibrate using dry and wet readings from your sensor.
const int MOISTURE_DRY_RAW = 3200;
const int MOISTURE_WET_RAW = 1400;
const float LOW_MOISTURE_PERCENT = 35.0;
const float HIGH_TEMP_C = 55.0;
const unsigned long READ_INTERVAL_MS = 10000;
const unsigned long PUMP_RUN_MS = 2000;

OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);
Servo sortingServo;
unsigned long lastRead = 0, pumpStartedAt = 0;
bool pumpRunning = false;

float clampValue(float v, float lo, float hi) {
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

float readMoisturePercent() {
  int raw = analogRead(MOISTURE_PIN);
  float pct = 100.0 * (MOISTURE_DRY_RAW - raw) /
              float(MOISTURE_DRY_RAW - MOISTURE_WET_RAW);
  return clampValue(pct, 0, 100);
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(500); Serial.print(".");
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("ESP32 IP: "); Serial.println(WiFi.localIP());
  } else Serial.println("Wi-Fi unavailable; will retry.");
}

void sendSensorData(float tempC, float moisture) {
  if (WiFi.status() != WL_CONNECTED) { WiFi.reconnect(); return; }
  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  StaticJsonDocument<192> doc;
  doc["temperature_c"] = tempC;
  doc["moisture_percent"] = moisture;
  doc["device"] = "esp32-prototype";
  String body;
  serializeJson(doc, body);
  int code = http.POST(body);
  Serial.printf("Server response: %d\\n", code);
  http.end();
}

// Example servo routing. Calibrate positions to your actual mechanism.
void routeWasteClass(String label) {
  label.toLowerCase();
  if (label == "food_waste" || label == "fruit_vegetable") sortingServo.write(35);
  else if (label == "paper") sortingServo.write(90);
  else if (label == "plastic" || label == "metal") sortingServo.write(145);
  else sortingServo.write(90); // safe default
  delay(800);
  sortingServo.write(90);
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  pinMode(PUMP_RELAY_PIN, OUTPUT);
  pinMode(FAN_RELAY_PIN, OUTPUT);
  digitalWrite(PUMP_RELAY_PIN, RELAY_OFF);
  digitalWrite(FAN_RELAY_PIN, RELAY_OFF);
  tempSensor.begin();
  sortingServo.setPeriodHertz(50);
  sortingServo.attach(SERVO_PIN, 500, 2400);
  sortingServo.write(90);
  connectWiFi();
}

void loop() {
  unsigned long now = millis();
  if (pumpRunning && now - pumpStartedAt >= PUMP_RUN_MS) {
    digitalWrite(PUMP_RELAY_PIN, RELAY_OFF);
    pumpRunning = false;
  }

  if (now - lastRead >= READ_INTERVAL_MS) {
    lastRead = now;
    tempSensor.requestTemperatures();
    float tempC = tempSensor.getTempCByIndex(0);
    float moisture = readMoisturePercent();
    Serial.printf("Temperature: %.2f C | Moisture: %.1f%%\\n", tempC, moisture);

    if (!pumpRunning && moisture < LOW_MOISTURE_PERCENT) {
      digitalWrite(PUMP_RELAY_PIN, RELAY_ON);
      pumpStartedAt = millis();
      pumpRunning = true;
    }
    digitalWrite(FAN_RELAY_PIN, (tempC > HIGH_TEMP_C) ? RELAY_ON : RELAY_OFF);

    if (tempC > -100 && tempC < 125) sendSensorData(tempC, moisture);
    else Serial.println("Temperature sensor error.");
  }
  delay(20);
}
